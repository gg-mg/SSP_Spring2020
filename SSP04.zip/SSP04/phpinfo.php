<?php 

session_start();
$_SESSION["secretWord"] = "Oranges";
$_SESSION["secretWord_hint"] = "A fruit in prural";
$_SESSION["secretWord_array"] = str_split($_SESSION["secretWord"]);
$_SESSION["secretWord_len"] = strlen($_SESSION["secretWord"]);;
$_SESSION["guess_secretWord"] = str_repeat("_", 7);
$_SESSION["guess_count"] = 0;
$_SESSION["guess_count_wrong"] = 0;
$_SESSION["guess_tracked"] = 0;
$_SESSION["guess_image"] = 0;
$_SESSION["guess_letter"] = "";
$_SESSION["game_lastGuess"] = date("F j, Y, g:i a");
$_SESSION["game_started"] = date("F j, Y, g:i a");



print_r ($_SESSION["secretWord"]);



echo session_name();


?>