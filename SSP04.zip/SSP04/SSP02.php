


    <?php include "PHP/include_header.php";?>

    <!-- navigation -->
    <?php include "PHP/include_leftNav.php";?>
    <?php include "PHP/include_topNav.php";?>  

<!-- main -->
    <main>      

        <?php include "PHP/include_dynamic_content.php";?>
    
    </main>

    <!-- footer -->

    <?php include "PHP/include_footer.php";?>
    
    
