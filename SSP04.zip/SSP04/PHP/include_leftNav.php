<aside>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="SSP02.php">SSP02</a></li>
                <li><a href="SSP03.php">SSP03</a></li>
                <li><a href="SSP04.php">SSP04</a></li>
                <li><a href="SSP05.php">SSP05</a></li>
                <li><a href="SSP06.php">SSP06</a></li>
                <li><a href="SSP07.php">SSP07</a></li>
                <li><a href="SSP08.php">SSP08</a></li>
                <li><a href="SSP09.php">SSP09</a></li>
                <li><a href="SSP10.php">SSP10</a></li>
                <li><a href="SSP11.php">SSP11</a></li>
                <li><a href="SSP12.php">SSP12</a></li>
            </ul>
        </nav>
    </aside>