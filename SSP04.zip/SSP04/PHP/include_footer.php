



<footer> 
    <hr>
    Dislaimer: Oklahoma City Community College does not necessarily
    endorse the content or the respective links on this web page.<br> 
    <?php
    echo filemtime("SSP02.php");
    echo "<br>";
    echo "Content last changed: ".date("F d Y H:i:s.", filemtime("SSP02.php"));
    ?>
</footer>
    
</body>
</html>
