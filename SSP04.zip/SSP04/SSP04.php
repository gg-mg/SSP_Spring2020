<?php
// Start the session
session_start();

// Set session variables


if ( isset($_SESSION["secretWord"]) ) {
    $secretWord = $_SESSION["secretWord"];
  }
if ( isset($_SESSION["secretWord_hint"]) ) {
    $secretWord_hint = $_SESSION["secretWord_hint"];
  }
if ( isset($_SESSION["secretWord_array"]) ) {
    $secretWord_array =$_SESSION["secretWord_array"];  }
  
if ( isset($_SESSION["secretWord_len"]) ) {
    $secretWord_len = $_SESSION["secretWord_len"];
  }
  if ( isset($_SESSION["guess_secretWord"] ) ) {
    $guess_secretWord = $_SESSION["guess_secretWord"] ;
  }
if ( isset($_SESSION["guess_count"]) ) {
    $guess_count = $_SESSION["guess_count"];
  }
  if ( isset($_SESSION["guess_count_wrong"] )) {
    $guess_count_wrong = $_SESSION["guess_count_wrong"];
  }
if ( isset($_SESSION["guess_tracked"]) ) {
    $guess_tracked = $_SESSION["guess_tracked"];
  }
  if ( isset($_SESSION["guess_image"] ) ) {
    $guess_image = $_SESSION["guess_image"] ;
  }
if ( isset($_SESSION["guess_letter"]) ) {
    $guess_letter= $_SESSION["guess_letter"];
  }
  if ( isset($_SESSION["game_lastGuess"] )) {
    $game_lastGuess= $_SESSION["game_lastGuess"];
  }
if ( isset($_SESSION["game_started"] ) ) {
    $game_started = $_SESSION["game_started"] ;
  }

  header("location:index.php"); // your current page


echo session_name();
  
print_r ($secretWord_array);

echo $game_lastGuess;

print_r ($_SESSION["secretWord_array"]);
echo str_repeat("_ &nbsp;", 7);
echo $secretWord_len ;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>


<form action="SSP04.php"  method="post">
<input type="text" name="frosty_letter_guess" placeholder="Enter a letter">
<input type="submit" name="submit">    
</form>



</body>
</html>

